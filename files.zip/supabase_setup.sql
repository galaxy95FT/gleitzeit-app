-- Gleitzeit App — Supabase Setup
-- Führe dieses Script im Supabase SQL Editor aus

-- Tabelle für Einträge
create table if not exists entries (
  id uuid default gen_random_uuid() primary key,
  date text not null unique,
  type text not null,
  start text,
  "end" text,
  start2 text,
  end2 text,
  actual_hours numeric,
  manual_break_min numeric,
  note text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Tabelle für Settings
create table if not exists settings (
  id integer primary key default 1,
  year integer default 2026,
  annual_vacation_days integer default 20,
  vacation_hours_per_day numeric default 8,
  vacation_carryover integer default 4,
  auto_break_threshold_h numeric default 6,
  auto_break_minutes integer default 30,
  scheduled_weekdays jsonb default '{"1":8,"2":8,"3":8,"4":8,"5":0}'::jsonb,
  updated_at timestamp with time zone default now()
);

-- Standard-Settings einfügen
insert into settings (id) values (1) on conflict (id) do nothing;

-- Row Level Security deaktivieren (für einfachen Zugriff ohne Auth)
alter table entries disable row level security;
alter table settings disable row level security;
