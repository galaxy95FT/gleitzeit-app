# Gleitzeit App 2026

## Setup

### 1. Supabase
Führe `supabase_setup.sql` im Supabase SQL Editor aus.

### 2. Lokal testen
```bash
npm install
npm run dev
```

### 3. GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/DEIN-USERNAME/gleitzeit-app.git
git push -u origin main
```

### 4. Netlify
- netlify.com → "Add new site" → "Import from GitHub"
- Repo auswählen → Deploy
- Fertig! 🎉
